RAHUL PHONE SMARTER APP — Android 16 / OPPO CPH2871 Starter Project

यह Android Studio source project है, अभी तैयार APK नहीं है।

इस संस्करण में:
- Battery temperature ACTION_BATTERY_CHANGED / EXTRA_TEMPERATURE से पढ़ा जाता है।
- Caller announcement के लिए Android CallScreeningService और ROLE_CALL_SCREENING का उपयोग होता है।
- Caller नाम Contacts में नंबर मिलने पर पढ़ने की कोशिश होती है; अन्यथा नंबर बोला जाता है।
- Call को reject/block नहीं किया जाता।

महत्वपूर्ण:
- Caller announcement Android 10+ पर Call Screening role मिलने पर ही काम कर सकता है।
- फोन/नेटवर्क की Caller ID privacy, unknown/private numbers, OEM background restrictions और Android behavior के कारण हर incoming call पर नंबर उपलब्ध होना सुनिश्चित नहीं है।
- हिंदी पुरुष आवाज़ तभी होगी जब डिवाइस में Hindi (India) TTS voice installed/selected हो। Settings > Additional settings / Accessibility / Text-to-speech output में उपलब्ध voice जाँचें।
- ऐप का APK इस ZIP में शामिल नहीं है। GitHub Actions workflow से debug APK बनाया जा सकता है।
- यह debug APK केवल निजी sideload/testing के लिए है; इसे Play Store पर प्रकाशित करने योग्य signed release bundle न समझें।
- इस प्रोजेक्ट को इस वातावरण में compile या OPPO फोन पर device-test नहीं किया गया है।

मोबाइल से APK बनाने का संक्षिप्त तरीका:
1. GitHub पर नया public या private repository बनाएँ।
2. ZIP को extract करके सभी files repository में upload करें; .github/workflows/build-apk.yml भी शामिल हो।
3. Actions tab खोलें और "Build Android APK" workflow चुनें।
4. Run workflow दबाएँ और build पूरा होने दें।
5. सफल run में Artifacts के नीचे rahul-phone-smarter-debug-apk डाउनलोड करें।
6. ZIP artifact extract करके app-debug.apk फोन में इंस्टॉल करें।
7. पहली बार Contacts permission दें और ऐप में ENABLE CALL ANNOUNCER दबाकर Android role स्वीकार करें।

नोट: GitHub की free Actions limits लागू होती हैं। किसी भी भुगतान वाले runner/plan की जरूरत नहीं होनी चाहिए; public repository पर standard hosted runner सामान्यतः free उपलब्ध रहता है।
