package com.rahul.phonesmarter

import android.Manifest
import android.content.pm.PackageManager
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallScreeningService
import android.speech.tts.TextToSpeech
import android.os.Build
import android.net.Uri
import java.util.Locale

class CallerScreeningService : CallScreeningService() {
    private var tts: TextToSpeech? = null

    override fun onScreenCall(details: Call.Details) {
        val incoming = Build.VERSION.SDK_INT >= 29 &&
            details.callDirection == Call.Details.DIRECTION_INCOMING
        val number = details.handle?.schemeSpecificPart?.takeIf { it.isNotBlank() }

        // Do not block or reject the call.
        respondToCall(details, CallResponse.Builder().setDisallowCall(false).build())

        if (incoming) {
            val contact = number?.let { findContactName(it) }
            val message = when {
                contact != null -> "आपको $contact का फोन आ रहा है"
                number != null -> "आपको इस नंबर से फोन आ रहा है $number"
                else -> "आपको किसी अनजान नंबर से फोन आ रहा है"
            }
            speakHindi(message)
        }
    }

    private fun findContactName(number: String): String? {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        return try {
            val lookupUri = ContactsContract.PhoneLookup.CONTENT_FILTER_URI.buildUpon()
                .appendPath(Uri.encode(number)).build()
            contentResolver.query(
                lookupUri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
                null, null, null
            )?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        } catch (_: Exception) { null }
    }

    private fun speakHindi(message: String) {
        if (tts == null) {
            tts = TextToSpeech(applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val result = tts?.setLanguage(Locale("hi", "IN"))
                    if (result == TextToSpeech.LANG_MISSING_DATA ||
                        result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        tts?.setLanguage(Locale("en", "IN"))
                    }
                    tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "caller_announcement")
                }
            }
        } else {
            tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "caller_announcement")
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }
}
