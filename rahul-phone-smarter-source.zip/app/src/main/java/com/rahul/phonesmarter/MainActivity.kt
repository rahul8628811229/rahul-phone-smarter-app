package com.rahul.phonesmarter

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private lateinit var tempText: TextView
    private lateinit var callStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createScreen()
        refreshBatteryTemperature()
        requestPermissionsIfNeeded()
    }

    private fun createScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(26, 34, 26, 26)
            setBackgroundColor(Color.rgb(10, 18, 38))
        }

        val title = TextView(this).apply {
            text = "RAHUL PHONE SMARTER APP"
            textSize = 23f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "YOUR PERSONAL PHONE ASSISTANT"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 28)
        }

        val batteryCard = makeCard()
        batteryCard.addView(makeLabel("BATTERY TEMPERATURE"))
        tempText = TextView(this).apply {
            text = "-- °C"
            textSize = 38f
            setTextColor(Color.rgb(82, 220, 160))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 12, 0, 8)
        }
        batteryCard.addView(tempText)
        batteryCard.addView(Button(this).apply {
            text = "REFRESH TEMPERATURE"
            setOnClickListener { refreshBatteryTemperature() }
        })

        val callerCard = makeCard()
        callerCard.addView(makeLabel("CALLER ANNOUNCER"))
        callStatus = TextView(this).apply {
            text = "अभी सेटअप नहीं हुआ"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 14, 0, 12)
        }
        callerCard.addView(callStatus)
        callerCard.addView(Button(this).apply {
            text = "ENABLE CALL ANNOUNCER"
            setOnClickListener { requestCallScreeningRole() }
        })

        val footer = TextView(this).apply {
            text = "Made by RAHUL THAKUR\nहिंदी आवाज़ के लिए फोन में Hindi Text-to-Speech उपलब्ध होना चाहिए।"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }

        root.addView(title, matchWrap())
        root.addView(subtitle, matchWrap())
        root.addView(batteryCard, matchWrap())
        root.addView(callerCard, matchWrap())
        root.addView(footer, matchWrap())
        setContentView(root)
    }

    private fun makeCard() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(20, 18, 20, 18)
        setBackgroundColor(Color.rgb(26, 39, 67))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 20 }
    }

    private fun makeLabel(value: String) = TextView(this).apply {
        text = value
        textSize = 13f
        setTextColor(Color.LTGRAY)
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun refreshBatteryTemperature() {
        val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val raw = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        tempText.text = if (raw >= 0) String.format(java.util.Locale.getDefault(), "%.1f °C", raw / 10.0)
                        else "Unavailable"
    }

    private fun requestPermissionsIfNeeded() {
        val needed = arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.READ_PHONE_STATE)
            .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), 10)
    }

    private fun requestCallScreeningRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(Context.ROLE_SERVICE) as RoleManager
            when {
                !roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) ->
                    callStatus.text = "इस फोन में Call Screening role उपलब्ध नहीं है"
                roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING) ->
                    callStatus.text = "Caller Announcer चालू है"
                else -> startActivityForResult(
                    roleManager.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 20
                )
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 20) {
            callStatus.text = if (resultCode == RESULT_OK) "Caller Announcer चालू है" else "अनुमति नहीं मिली"
        }
    }
}
